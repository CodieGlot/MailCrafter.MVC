import subprocess
import os

def run_fill_data(package_path):

    try:
        # Get the local app data path from environment variables
        local_app_data = os.environ.get('LOCALAPPDATA')
        
        # Path to UiRobot.exe
        uirobot_path = os.path.join(local_app_data, 'Programs', 'UiPath', 'Studio', 'UiRobot.exe')
        
        # Check if the executable exists
        if not os.path.exists(uirobot_path):
            return False, f"Executor not found at {uirobot_path}"
        
        # Check if the package exists
        if not os.path.exists(package_path):
            return False, f"Package file not found at {package_path}"
        
        # Command to execute
        command = [uirobot_path, 'execute', '--file', package_path]
        
        # Run the process
        print(f"Starting input to erp process: {' '.join(command)}")
        
        # Execute the command and capture output
        result = subprocess.run(
            command, 
            capture_output=True, 
            text=True, 
            check=False
        )
        
        # Check if process was successful
        if result.returncode == 0:
            print("input data successfully sent to erp")
            return True, result.stdout
        else:
            print(f"input data error {result.returncode}")
            return False, result.stderr
            
    except Exception as e:
        print(f"Error input data to app: {str(e)}")
        return False, str(e)

if __name__ == "__main__":
    # Path to your UiPath package
    package_path = r"D:\SEP490\Test\Invoice.POC.1.0.3.nupkg"
    
    # Run the UiPath process
    success, message = run_fill_data(package_path)
    
    if success:
        print("Process executed successfully!")
        print("Output:")
        print(message)
    else:
        print("Process execution failed!")
        print("Error:")
        print(message)