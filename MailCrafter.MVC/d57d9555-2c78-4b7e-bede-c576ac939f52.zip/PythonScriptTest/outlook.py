import win32com.client as client
from typing import List, Optional, Tuple
 
 
class Outlook:
    """
    Automate Outlook tasks
    """
 
    def __init__(self) -> None:
        self.ol, self.namespace, self.default_account = self.__get_outlook_config()
 
    @staticmethod
    def __get_outlook_config() -> (
        Tuple[client.Dispatch, client.Dispatch, client.Dispatch]
    ):
        """
        Initialize connection to Outlook, return a tuple for Application object, namespace object, default account
        """
        try:
            ol = client.Dispatch("outlook.application")
            namespace = ol.GetNamespace("MAPI")
            default_account = ol.Session.Accounts[0]
            return ol, namespace, default_account
        except Exception as e:
            raise Exception(f"Error initializing Outlook connection: {str(e)}")
 
    def __get_folder(
        self, folder_name: str, account_address: Optional[str] = None
    ) -> client.Dispatch:
        """
        Retrieve Outlook folder object
        - account_address: account address where target folder is stored
        - folder_name: target folder, e.g., Inbox
        """
        try:
            used_account = (
                self.default_account
                if (account_address is None or account_address == "")
                else [
                    account
                    for account in self.namespace.Accounts
                    if account.DisplayName.lower() == account_address
                ][0]
            )
            # Modify root_folder to follow the hierarchy path
            # Eg: Inbox > PD > UC249 then the below code should be modified like this:
            # root_folder = self.namespace.Folders(used_account.DisplayName).Folders("Inbox").Folders("PD")
            root_folder = self.namespace.Folders(used_account.DisplayName).Folders(
                "Inbox"
            )
            folder = (
                root_folder.Folders(folder_name)
                if folder_name != "Inbox"
                else root_folder
            )
            return folder
        except Exception as e:
            raise Exception(f'Error retrieving folder "{folder_name}": {str(e)}')
 
    @staticmethod
    def delete_mail_message(mail_item: client.Dispatch) -> None:
        """
        Delete Email message
        - mail_item: email that exists in Outlook folder
        """
        try:
            mail_item.Delete()
        except Exception as e:
            raise Exception(f"Error deleting mail message: {str(e)}")
 
    @staticmethod
    def mark_as_read_unread(mail_item: client.Dispatch, mark_unread: bool) -> None:
        """
        Mark mail message as read/unread:
        - mail_item: MailItem object
        - mark_unread: False=Mark as read, True=Mark as unread
        """
        try:
            mail_item.UnRead = mark_unread
        except Exception as e:
            raise Exception(f"Error marking message as read/unread: {str(e)}")
 
    def send_mail_message(
        self,
        mailTo: str,
        mailFrom: Optional[str] = None,
        mailCC: Optional[str] = None,
        subject: Optional[str] = None,
        body: Optional[str] = None,
        attachments: Optional[List[str]] = [],
        isBodyHtml: Optional[bool] = False,
    ) -> Tuple[bool, str]:
        """
        Send email using Outlook:
        - mailFrom (str): account used to send email
        - mailTo (str): recipient(s)' email address
        - mailCC (str): recipient(s)' email address for CC
        - subject (str): email's subject
        - body (str): email's body
        - attachments (list): list of attachments
        - isBodyHtml (bool): True if the body is HTML, False if it's plain text
        """
        try:
            mail_item = self.ol.CreateItem(0)
            used_account = (
                self.default_account
                if (mailFrom is None or mailFrom == "")
                else [
                    account
                    for account in self.namespace.Accounts
                    if account.DisplayName.lower() == mailFrom
                ][0]
            )
            mail_item.SendUsingAccount = used_account
 
            mail_item.To = mailTo
            mail_item.CC = mailCC if (mailCC is not None and mailCC != "") else ""
            mail_item.Subject = (
                subject if (subject is not None and subject != "") else ""
            )
 
            if body is not None and body != "":
                if isBodyHtml:
                    mail_item.HTMLBody = body
                else:
                    mail_item.Body = body
 
            for attachment in attachments:
                mail_item.Attachments.Add(attachment)
 
            mail_item.Send()
            return True, ""
        except Exception as e:
            return False, f"Error sending email: {str(e)}"
 
    def get_mail_messages(
        self,
        account_address: Optional[str] = None,
        folder_name: Optional[str] = "Inbox",
        max_mail_count: Optional[int] = 10,
        filter: Optional[str] = None,
        unread_only: Optional[bool] = True,
        sortby_receive_time: Optional[bool] = True,
    ) -> List[client.Dispatch]:
        """
        Retrieve list of mail messages
        - account_address: target email address that is used to retrieve mail messages
        - folder_name: name of target folder to retrieve mail messages
        - max_mail_count: maximum number of mail messages to retrieve
        - filter: criteria to filter mail messages (Reference: https://learn.microsoft.com/en-us/office/vba/api/outlook.items.restrict?source=recommendations)
        - unread_only: retrieve only unread messages
        - sortby_receive_time: sort the messages by received time
        """
        try:
            used_account_address = (
                self.default_account.DisplayName
                if account_address is None or account_address == ""
                else account_address
            )
            folder = self.__get_folder(
                folder_name, account_address=used_account_address
            )
 
            combined_filter = "[UnRead] = True" if unread_only else ""
            if filter is not None and filter != "":
                combined_filter = (
                    combined_filter + " AND " + filter if combined_filter else filter
                )
 
            messages = (
                folder.Items.Restrict(combined_filter)
                if combined_filter
                else folder.Items
            )
            messages.Sort("[ReceivedTime]", sortby_receive_time)
 
            return (
                list(messages)[:max_mail_count]
                if len(messages) >= max_mail_count
                else list(messages)
            )
        except Exception as e:
            raise Exception(
                f'Error retrieving mail messages from "{folder_name}": {str(e)}'
            )
 
    def move_mail_message(
        self,
        mail_item: client.Dispatch,
        dest_folder: str,
        folder_account: Optional[str] = None,
    ) -> None:
        """
        Move mail message to target folder
        - mail_item: mail message item
        - dest_folder: target folder to move mail message to
        - folder_account: target account that stores target folder
        """
        try:
            folder = self.__get_folder(dest_folder, account_address=folder_account)
            mail_item.Move(folder)
        except Exception as e:
            raise Exception(f'Error moving mail message to "{dest_folder}": {str(e)}')
 
 
if __name__ == "__main__":
    obj=Outlook()
    obj.send_mail_message(mailTo="gaurav_sbari@singaporeair.com.sg",mailFrom="gaurav_sbari@singaporeair.com.sg",subject="test",body="test123")