
import argparse
import os
import google.generativeai as genai

def main():
    parser = argparse.ArgumentParser(description='Send a message to an API and save the response.')
    
    # Add the arguments
    parser.add_argument('--messagefile', type=str, required=True, help='The message file to be read')
    parser.add_argument('--fileresponse', type=str, required=True, help='The filename to save the response')
    parser.add_argument('--apikey', type=str, required=True, help='Your API key')

    args = parser.parse_args()
    
    message_file = args.messagefile
    response_file = args.fileresponse
    apikey = args.apikey
    genai.configure(api_key=apikey)

    file_name, _= os.path.splitext(os.path.basename(message_file))
    print(f'Processing file: {file_name}')
    with open(message_file, 'r', encoding='utf-8') as file:
            message = file.read().strip()

    # Create the model
    generation_config = {
      "temperature": 1,
      "top_p": 0.95,
      "top_k": 64,
      "max_output_tokens": 8000,
      "response_mime_type": "application/json",
    }

    model = genai.GenerativeModel(
      model_name="gemini-1.5-flash",
      generation_config=generation_config,
      # safety_settings = Adjust safety settings
      # See https://ai.google.dev/gemini-api/docs/safety-settings
    )

    chat_session = model.start_chat(
      history=[
      ]
    )

    response = chat_session.send_message(message)

    print(response.text)
    with open(response_file, "w", encoding="utf-8") as f:
        f.write(response.text)
        
if __name__ == "__main__":
    main()