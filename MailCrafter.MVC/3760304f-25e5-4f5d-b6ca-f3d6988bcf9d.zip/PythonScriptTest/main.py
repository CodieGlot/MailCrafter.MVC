from outlook import Outlook
import os
from gemini import generate
import os.path
from fill_data import run_fill_data
import time
def get_unread_invoice_messages(account=None, max_count=10, download_folder=None, process_attachments=False):
    """
    Retrieve unread messages from the Inbox folder that have "Invoice" in the subject
    and download any attachments to the specified folder
    
    Args:
        account (str, optional): Email account to use. If None, uses default account.
        max_count (int, optional): Maximum number of emails to retrieve. Defaults to 10.
        download_folder (str, optional): Folder path to save attachments. If None, attachments won't be downloaded.
        process_attachments (bool, optional): Whether to process PDF attachments with Gemini. Defaults to False.
    
    Returns:
        list: List of unread mail messages with "Invoice" in the subject
    """
    try:
        # Initialize Outlook client
        outlook = Outlook()
        
        # Get unread messages from Inbox
        messages = outlook.get_mail_messages(
            account_address=account,
            folder_name="Inbox",
            max_mail_count=max_count,
            unread_only=True,
            sortby_receive_time=True
        )
        
        # Filter messages to only include those with "Invoice" in the subject
        invoice_messages = [msg for msg in messages if "invoice" in msg.Subject.lower()]
        
        print(f"Found {len(invoice_messages)} unread invoice messages in Inbox")
        
        # Create download folder if it doesn't exist and is specified
        if download_folder and not os.path.exists(download_folder):
            os.makedirs(download_folder)
            print(f"Created folder: {download_folder}")
        
        # Process each message
        processed_files = []
        for i, msg in enumerate(invoice_messages, 1):
            print(f"Invoice {i}:")
            print(f"  Subject: {msg.Subject}")
            print(f"  Sender: {msg.SenderName}")
            print(f"  Received: {msg.ReceivedTime}")
            print(f"  Has Attachments: {'Yes' if msg.Attachments.Count > 0 else 'No'}")
            
            # Download attachments if folder is specified
            if download_folder and msg.Attachments.Count > 0:
                print(f"  Downloading {msg.Attachments.Count} attachment(s):")
                for j in range(1, msg.Attachments.Count + 1):
                    attachment = msg.Attachments.Item(j)
                    file_path = os.path.join(download_folder, attachment.FileName)
                    try:
                        attachment.SaveAsFile(file_path)
                        print(f"    - Saved: {attachment.FileName}")
                        
                        # Process PDF attachment with Gemini if requested
                        if process_attachments and file_path.lower().endswith('.pdf'):
                            print(f"    - Processing PDF with Gemini AI: {attachment.FileName}")
                            output_json = f"{os.path.splitext(file_path)[0]}_data.json"
                            result = generate(file_path, output_json)
                            processed_files.append({
                                'original_pdf': file_path,
                                'extracted_json': output_json,
                                'message': msg
                            })
                            print(f"    - Extraction complete: {output_json}")
                            
                    except Exception as save_error:
                        print(f"    - Failed to save {attachment.FileName}: {str(save_error)}")
            
            print("-" * 50)
        
        return invoice_messages, processed_files
        
    except Exception as e:
        print(f"An error occurred: {str(e)}")
        return [], []


def send_email_from_specific_account():
    """
    Send an email using a specific Outlook account
    """
    try:
        # Initialize Outlook client
        outlook = Outlook()
        
        # Specify which account to use (use the display name of your Outlook account)
        # For example: "john.doe@company.com" or "Personal Account"
        sender_account = "mingo.dev@outlook.com"   # Replace with your actual account display name
        
        # Email parameters
        recipient = "mingo.dev@outlook.com"  # Replace with actual recipient
        subject = "Test Email from Specific Account"
        body = """
        Hello,
        
        This is a test email sent using Python and a specific Outlook account.
        
        Regards,
        Your Name
        """
        
        # Send the email using the specified account
        success, message = outlook.send_mail_message(
            mailTo=recipient,
            mailFrom=sender_account,  # This specifies which account to use
            subject=subject,
            body=body
        )
        
        if success:
            print(f"Email sent successfully from {sender_account}!")
        else:
            print(f"Failed to send email: {message}")
            
    except Exception as e:
        print(f"An error occurred: {str(e)}")


def send_extraction_to_specific_address(processed_files, account=None, recipient_email="youremail@example.com"):
    """
    Send extracted invoice data to a specific email address
    
    Args:
        processed_files (list): List of dictionaries containing processed file info
        account (str, optional): Email account to use for sending
        recipient_email (str): Specific email address to send the data to
    """
    if not processed_files:
        print("No processed files to send")
        return
    
    outlook = Outlook()
    
    for item in processed_files:
        try:
            msg = item['message']
            json_path = item['extracted_json']
            pdf_name = os.path.basename(item['original_pdf'])
            
            # Read the JSON file content
            with open(json_path, 'r', encoding='utf-8') as f:
                json_content = f.read()
            
            # Create email subject and body
            email_subject = f"Invoice Data Extraction: {pdf_name}"
            email_body = f"""
            Hello,
            
            The invoice attachment '{pdf_name}' from {msg.SenderName} has been processed.
            Subject of original email: {msg.Subject}
            Received on: {msg.ReceivedTime}
            
            The extracted data is provided below:
            
            {json_content}
            
            This is an automated message.
            """
            
            # Send email to specific address
            success, message = outlook.send_mail_message(
                mailTo=recipient_email,
                mailFrom=account,
                subject=email_subject,
                body=email_body,
                attachments=[json_path, item['original_pdf']]  # Attach both JSON and original PDF
            )
            
            if success:
                print(f"Data sent successfully to {recipient_email} for invoice: {pdf_name}")
                # Mark original as read
                outlook.mark_as_read_unread(msg, False)
            else:
                print(f"Failed to send data for {pdf_name}: {message}")
                
        except Exception as e:
            print(f"Error sending message: {str(e)}")
    
    outlook = Outlook()
    
    for item in processed_files:
        try:
            msg = item['message']
            json_path = item['extracted_json']
            pdf_name = os.path.basename(item['original_pdf'])
            
            # Read the JSON file content
            with open(json_path, 'r', encoding='utf-8') as f:
                json_content = f.read()
            
            # Create reply
            reply_subject = f"RE: {msg.Subject} - Data Extraction Results"
            reply_body = f"""
            Hello,
            
            The invoice attachment '{pdf_name}' has been processed.
            The extracted data is provided below:
            
            {json_content}
            
            This is an automated response.
            """
            
            # Send reply
            success, message = outlook.send_mail_message(
                mailTo=msg.SenderEmailAddress,
                mailFrom=account,
                subject=reply_subject,
                body=reply_body,
                attachments=[json_path]  # Attach the JSON file
            )
            
            if success:
                print(f"Reply sent successfully for invoice: {pdf_name}")
                # Mark original as read
                outlook.mark_as_read_unread(msg, False)
            else:
                print(f"Failed to send reply for {pdf_name}: {message}")
                
        except Exception as e:
            print(f"Error replying to message: {str(e)}")


if __name__ == "__main__":
    account_name = "mingo.dev@outlook.com"
    recipient_email = "hoainxde140218@gmail.com"  # Replace with the specific email address
    
    # Specify the folder where you want to download attachments
    download_path = r"D:\SEP490\Downloaded Documents"
    
    # Get unread invoice messages and process PDF attachments with Gemini
    messages, processed_files = get_unread_invoice_messages(
        account=account_name, 
        max_count=1, 
        download_folder=download_path,
        process_attachments=True  # Enable Gemini processing
    )
    
    # Send extracted data to a specific email address
    if processed_files:
        send_extraction_to_specific_address(
            processed_files, 
            account=account_name,
            recipient_email=recipient_email
        )
    time.sleep(2) 
    run_fill_data(r"D:\SEP490\Test\Invoice.POC.1.0.3.nupkg")