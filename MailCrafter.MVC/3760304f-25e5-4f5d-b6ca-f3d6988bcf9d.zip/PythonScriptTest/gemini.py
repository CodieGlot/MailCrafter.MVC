import base64
import os
from google import genai
from google.genai import types


def generate(file_path, output_file="invoice_data.json"):
    client = genai.Client(
        api_key="AIzaSyAhs9D8dV579EtT-FW8EVleBkoAM0R_F4Y",
    )

    files = [
        # Make the file available in local system working directory
        client.files.upload(file=file_path),
    ]
    model = "gemini-2.0-flash"
    contents = [
        types.Content(
            role="user",
            parts=[
                types.Part.from_uri(
                    file_uri=files[0].uri,
                    mime_type=files[0].mime_type,
                ),
                types.Part.from_text(text="Extract json information from the PDF"),
            ],
        ),
    ]
    generate_content_config = types.GenerateContentConfig(
        temperature=1,
        top_p=0.95,
        top_k=40,
        max_output_tokens=8192,
        response_mime_type="application/json",
        response_schema=genai.types.Schema(
            type = genai.types.Type.OBJECT,
            required = ["general_info", "table"],
            properties = {
                "general_info": genai.types.Schema(
                    type = genai.types.Type.OBJECT,
                    required = ["vendor", "no", "sub-total", "total", "tax-amount", "tax-rate"],
                    properties = {
                        "vendor": genai.types.Schema(
                            type = genai.types.Type.STRING,
                        ),
                        "no": genai.types.Schema(
                            type = genai.types.Type.STRING,
                        ),
                        "sub-total": genai.types.Schema(
                            type = genai.types.Type.STRING,
                        ),
                        "total": genai.types.Schema(
                            type = genai.types.Type.STRING,
                        ),
                        "tax-amount": genai.types.Schema(
                            type = genai.types.Type.STRING,
                        ),
                        "tax-rate": genai.types.Schema(
                            type = genai.types.Type.STRING,
                        ),
                    },
                ),
                "table": genai.types.Schema(
                    type = genai.types.Type.ARRAY,
                    items = genai.types.Schema(
                        type = genai.types.Type.OBJECT,
                        required = ["no", "description", "unit", "quantity", "unit_price", "amount"],
                        properties = {
                            "no": genai.types.Schema(
                                type = genai.types.Type.STRING,
                            ),
                            "description": genai.types.Schema(
                                type = genai.types.Type.STRING,
                            ),
                            "unit": genai.types.Schema(
                                type = genai.types.Type.STRING,
                            ),
                            "quantity": genai.types.Schema(
                                type = genai.types.Type.STRING,
                            ),
                            "unit_price": genai.types.Schema(
                                type = genai.types.Type.STRING,
                            ),
                            "amount": genai.types.Schema(
                                type = genai.types.Type.STRING,
                            ),
                        },
                    ),
                ),
            },
        ),
    )

    # Collect the entire response
    full_response = ""
    for chunk in client.models.generate_content_stream(
        model=model,
        contents=contents,
        config=generate_content_config,
    ):
        if chunk.text:
            full_response += chunk.text
            print(chunk.text, end="")  # Still print to console for monitoring
    
    # Write complete response to a file
    with open(output_file, 'w', encoding='utf-8') as f:
        f.write(full_response)
    
    print(f"\n\nResponse saved to {output_file}")
    return full_response

if __name__ == "__main__":
    # Update this path to your actual PDF file
    pdf_file_path = "SMV40000123.pdf"
    output_file_path = "invoice_extracted_data.json"
    generate(pdf_file_path, output_file_path)